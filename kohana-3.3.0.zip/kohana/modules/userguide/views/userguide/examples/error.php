<?php

// Should trigger an ErrorException with an E_NOTICE level
echo $var_does_not_exist;

?>