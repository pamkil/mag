<?php defined('SYSPATH') or die('No direct script access.');

class Kodoc extends Kohana_Kodoc {}
