<?php defined('SYSPATH') or die('No direct script access.');

abstract class Unittest_TestCase extends Kohana_Unittest_TestCase {}
