<?php defined('SYSPATH') OR die('No direct script access.');

class Validation extends Kohana_Validation {}
