<?php defined('SYSPATH') OR die('No direct script access.');

class Date extends Kohana_Date {}
