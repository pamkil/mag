<?php defined('SYSPATH') OR die('No direct script access.');

abstract class HTTP extends Kohana_HTTP {}